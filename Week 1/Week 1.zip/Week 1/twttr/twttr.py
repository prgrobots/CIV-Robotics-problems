# twttr.py

def remove_vowels(input_str):
    """
    Remove vowels (A, E, I, O, U) from the input string.

    Parameters:
    - input_str (str): The input string.

    Returns:
    - str: The input string with vowels removed.
    """
 


if __name__ == "__main__":
    user_input = input("Enter a string: ")
    output = remove_vowels(user_input)
    print(output)
